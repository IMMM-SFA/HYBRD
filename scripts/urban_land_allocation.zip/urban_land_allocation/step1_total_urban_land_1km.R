
library(lme4)
library(MuMIn)
library(ggplot2)

urb_dat <- read.csv(file="HYBRD_Model_code/urban_land_allocation/inputs/base_gao_nlcd_1km_total_urban_area.csv", header=TRUE)

pred1 <-read.csv(file="HYBRD_Model_code/urban_land_allocation/inputs/gao_nlcd_1km_totalarea_all_scenarios.csv", header=TRUE)


predictors <- pred1

urb_dat$MeanSlope2 <- urb_dat$MeanSlope/100
pred1$MeanSlope2 <- pred1$MeanSlope/100

##prep predictor data urban area

nrow(pred1)
length <- nrow(pred1)
x <- seq(1,length, by=1) 
x <- as.data.frame(x)
x$urb_type <- "21_24"
y <- seq(1,length, by=1) 
y <- as.data.frame(y)
y$urb_type <- "22_24"
x <- x[-c(1)]
y <- y[-c(1)]


preda <- cbind(pred1, x)
predb <- cbind(pred1, y)
predictors <- rbind(preda,predb)

predictors$select_frac <- predictors$select_frc
colnames(predictors)[6] <- "focal_3cell"
colnames(predictors)[7] <- "focal_5cell"
colnames(predictors)[1] <- "Value"
predictors$Value <- as.factor(predictors$Value)


urb_dat$urb_type <- as.factor(urb_dat$urb_type)    

colnames(urb_dat)
#[1] "gridcode"    "Scenario"    "ssp"         "Year"        "id"          "select_frac" "focal_3cell" "focal_5cell"
#[9] "CellArea"    "Water"       "Wetland"     "PFWater"     "PFWetland"   "PFWW"        "SlopClass1"  "SlopClass2" 
#[17] "SlopClass3"  "PFSlope2"    "PFSlope3"    "MeanSlope"   "urb_type"    "urb_area"


#### LMER models predicting raw area

urb_mod <- lmer(urb_area ~ select_frac + focal_3cell + focal_5cell + PFWW + PFSlope2 +  PFSlope3 + MeanSlope + (1|urb_type) + (1|gridcode), data=urb_dat, control = lmerControl(optimizer ="Nelder_Mead"))




## validation
resp <- predict(urb_mod, type="response")
resp <- as.data.frame(cbind(resp, urb_dat$urb_area, urb_dat$urb_type))
colnames(resp) <- c("Predicted", "Observed", "NLCD_class")

#R2
summary(lm(Observed ~ Predicted, data=resp))


## Plot predicted and observed
ggplot(resp, aes(x=Predicted, y=Observed, color=NLCD_class)) + geom_point() + geom_smooth()

resp$NLCD_class <- as.factor(resp$NLCD_class)

ggplot(resp, aes(x=Predicted, y=Observed, group=NLCD_class)) + geom_point(aes(color=NLCD_class, alpha=0.8)) +
  geom_smooth(aes(linetype=NLCD_class, color=NLCD_class)) +
  scale_color_manual(values=c('#a50f15', '#fb6a4a')) +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))



######################
### Predicting scenarios
##predict for all scenarios
pred_urbarea.all <- predict(urb_mod, predictors, type="response")
write.csv(pred_urbarea.all, file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_urban_area_all_scenarios.csv")


