library(glmmTMB)
library(ggplot2)
library(lme4)


nl_pft <-read.csv(file="HYBRD_Model_code/urban_land_allocation/inputs/nlcd_all_years.csv", header=TRUE)
nl_pft$Value <- as.factor(nl_pft$GRIDCODE)
nl_pft$urb_type <- as.factor(nl_pft$urb_type)


colnames(nl_pft)
#[1] "GRIDCODE"  "VALUE_11"  "VALUE_21"  "VALUE_22"  "VALUE_23"  "VALUE_24"  "VALUE_31"  "VALUE_41"  "VALUE_42"  "VALUE_43"  "VALUE_52" 
#[12] "VALUE_71"  "VALUE_81"  "VALUE_82"  "VALUE_90"  "VALUE_95"  "Year"      "CellArea"  "UrbanArea" "urb_type"  "PFT_UT"    "UT1"      
#[23] "UT0"       "Value"  

#adjust variables
nl_pft$Year2 <- nl_pft$Year-2000
nl_pft$Pop2 <- log(nl_pft$Population)


### Model - generalized linear mixed model

nl_model_binom1 <- glmer(cbind(UT1, UT0) ~  Pop2*urb_type + (Pop2|Value:urb_type), data=nl_pft, family=binomial, control = glmerControl(optimizer="nloptwrap", calc.derivs = FALSE))


## Model validation
pfit1 <- predict(nl_model_binom1, type="response")
nl_pft$urb_type <- as.factor(nl_pft$urb_type)
levels(nl_pft$urb_type)
resp_n1 <- as.data.frame(cbind(pfit1, nl_pft$PFT_UT, nl_pft$urb_type))

colnames(resp_n1) <- c("Predicted", "Observed", "NLCD_class")

ggplot(resp_n1, aes(x=Predicted, y=Observed, color=NLCD_class)) + geom_point() + geom_smooth()


lmR2 <- lm(Observed ~ Predicted, data=resp_n1)
anova(lmR2)
summary(lmR2)


## Plot prediction vs observations

resp_n1$NLCD_class <- as.factor(resp_n1$NLCD_class)

ggplot(resp_n1, aes(x=Predicted, y=Observed, group=NLCD_class)) + geom_point(aes(color=NLCD_class, alpha=0.5)) +
  geom_smooth(aes(linetype=NLCD_class, color=NLCD_class)) +
  scale_color_manual(values=c('#a50f15', '#de2d26', '#fb6a4a', '#fcae91')) +
  xlab("Predicted") + ylab("Observed") + 
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))



## Model predictions for scenarios

pred_nl_pft <- read.csv(file="HYBRD_Model_code/urban_land_allocation/inputs/nlcd_scenarios_allyears.csv", header=TRUE)

pred_nl_pft$Pop2 <- log(pred_nl_pft$Pop_SSP1)
pred.allyears_SSP1 <- predict(nl_model_binom1, pred_nl_pft, type="response")
write.csv(pred.allyears_Orig_SSP1, file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Updated_SSP1.csv")

pred_nl_pft$Pop2 <- log(pred_nl_pft$Pop_SSP2)
pred.allyears_SSP2 <- predict(nl_model_binom1, pred_nl_pft, type="response")
write.csv(pred.allyears_Orig_SSP1, file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Updated_SSP2.csv")

pred_nl_pft$Pop2 <- log(pred_nl_pft$Pop_SSP3)
pred.allyears_SSP3 <- predict(nl_model_binom1, pred_nl_pft, type="response")
write.csv(pred.allyears_Orig_SSP1, file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Updated_SSP3.csv")

pred_nl_pft$Pop2 <- log(pred_nl_pft$Pop_SSP4)
pred.allyears_SSP4 <- predict(nl_model_binom1, pred_nl_pft, type="response")
write.csv(pred.allyears_Orig_SSP1, file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Updated_SSP4.csv")

pred_nl_pft$Pop2 <- log(pred_nl_pft$Pop_SSP5)
pred.allyears_SSP5 <- predict(nl_model_binom1, pred_nl_pft, type="response")
write.csv(pred.allyears_Orig_SSP1, file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Updated_SSP5.csv")





