
## start by reclassifying nlcd
lc_1 <- nlcd_2000


#################################
###########################
###########
######  INITIATE LOOP



for (row in 1:nrow(sdl)) {
  Year <- sdl[row, "Year"]
  SSP <- sdl[row, "SSP"]
  out_table  <- sdl[row, "table_out"]
  out_raster <- sdl[row, "raster_out"]
  out_raster_adj  <- sdl[row, "raster_out_adj"]


############
###########
#####  urban area selection

scen_urban_area <- area_pred[which(area_pred$SSP==SSP&area_pred$Year==Year),]
  
  
#################################
###########################
###########
######  LAND SUITABILITY
  

rclass21 <- c(11, 0, 21, 1, 22, 0, 23, 0, 24, 0, 31, 0, 41, 0, 42, 0, 43, 0, 52, 0, 71, 0, 81,0, 82,0,90, 0, 95,0, 128,0)
rclass22 <- c(11, 0, 21, 0, 22, 1, 23, 0, 24, 0, 31, 0, 41, 0, 42, 0, 43, 0, 52, 0, 71, 0, 81,0, 82,0,90, 0, 95,0,128,0)
rclass23 <- c(11, 0, 21, 0, 22, 0, 23, 1, 24, 0, 31, 0, 41, 0, 42, 0, 43, 0, 52, 0, 71, 0, 81,0, 82,0,90, 0, 95,0,128,0)
rclass24 <- c(11, 0, 21, 0, 22, 0, 23, 0, 24, 1, 31, 0, 41, 0, 42, 0, 43, 0, 52, 0, 71, 0, 81,0, 82,0,90, 0, 95, 0,128,0)


rclmat21 <- matrix(rclass21, ncol=2, byrow=TRUE)
rclmat22 <- matrix(rclass22, ncol=2, byrow=TRUE)
rclmat23 <- matrix(rclass23, ncol=2, byrow=TRUE)
rclmat24 <- matrix(rclass24, ncol=2, byrow=TRUE)


rc1_21 <- reclassify(lc_1, rclmat21, pad=TRUE, padValue=100, na.rm=FALSE)
rc1_22 <- reclassify(lc_1, rclmat22, pad=TRUE, padValue=100, na.rm=FALSE)
rc1_23 <- reclassify(lc_1, rclmat23, pad=TRUE, padValue=100, na.rm=FALSE)
rc1_24 <- reclassify(lc_1, rclmat24, pad=TRUE, padValue=100, na.rm=FALSE)

fw <- focalWeight(rc1_21,d=c(30), type=c("Gauss"))

frc1_21 <- focal(rc1_21, w=fw, fun="mean", pad=TRUE, padValue=100, na.rm=FALSE)
frc1_22 <- focal(rc1_22, w=fw, fun="mean", pad=TRUE, padValue=100, na.rm=FALSE)
frc1_23 <- focal(rc1_23, w=fw, fun="mean", pad=TRUE, padValue=100, na.rm=FALSE)
frc1_24 <- focal(rc1_24, w=fw, fun="mean", pad=TRUE, padValue=100, na.rm=FALSE)

frc1_21[is.na(frc1_21)] <- 0
frc1_22[is.na(frc1_22)] <- 0
frc1_23[is.na(frc1_23)] <- 0
frc1_24[is.na(frc1_24)] <- 0


rs21 <- stack(lc_1, frc1_21)
ts21 <- calc(rs21, sum)
ts21b <- stack(lc_1, ts21, grid2, lndincl)
dts21b <- as.data.frame(ts21b, xy=TRUE)

rs22 <- stack(lc_1, frc1_22)
ts22 <- calc(rs22, sum)
dts22b <- as.data.frame(ts22, xy=TRUE)


rs23 <- stack(lc_1, frc1_23)
ts23 <- calc(rs23, sum)
dts23b <- as.data.frame(ts23, xy=TRUE)

rs24 <- stack(lc_1, frc1_24)
ts24 <- calc(rs24, sum)
dts24b <- as.data.frame(ts24, xy=TRUE)


dtsbulk <- cbind(dts21b, dts22b, dts23b, dts24b)

dtsbulk =subset(dtsbulk, select=-c(7,8))
dtsbulk =subset(dtsbulk, select=-c(8,9))
dtsbulk =subset(dtsbulk, select=-c(9,10))

names(dtsbulk) <- c("longitude", "latitude", "nlcd_class", "trans_21", "Value", "lndincl", "trans_22", "trans_23", "trans_24")





#################################
###########################
###########
######  LAND TRANSITION STEP

h <- merge(dtsbulk, scen_urban_area, by="Value", all.x=TRUE)

## create land transition priority for ncld 24

order_24 <- 
  ifelse(h$trans_24>=24&h$trans_24<25&h$lndincl==1, 1+(25-h$trans_24), 
         ifelse(h$trans_24>=23&h$trans_24<24&h$lndincl==1, 2+(24-h$trans_24), 
                ifelse(h$trans_24>=22&h$trans_24<23&h$lndincl==1, 3+(23-h$trans_24), 
                       ifelse(h$trans_24>=21&h$trans_24<22&h$lndincl==1, 4+(22-h$trans_24), 
                              ifelse(h$trans_24>=31&h$trans_24<32&h$lndincl==1, 5+(32-h$trans_24), 
                                     ifelse(h$trans_24>=52&h$trans_24<53&h$lndincl==1, 6+(53-h$trans_24),
                                            ifelse(h$trans_24>=71&h$trans_24<72&h$lndincl==1, 7+(72-h$trans_24), 
                                                   ifelse(h$trans_24>=81&h$trans_24<82&h$lndincl==1, 8+(82-h$trans_24), 
                                                          ifelse(h$trans_24>=82&h$trans_24<83&h$lndincl==1, 9+(83-h$trans_24), 
                                                                 ifelse(h$trans_24>=42&h$trans_24<43&h$lndincl==1, 10+(43-h$trans_24), 
                                                                        ifelse(h$trans_24>=43&h$trans_24<44&h$lndincl==1, 11+(44-h$trans_24), 
                                                                               ifelse(h$trans_24>=41&h$trans_24<42&h$lndincl==1, 12+(42-h$trans_24), 
                                                                                      20))))))))))))

j <- cbind(h, order_24)
n <- nrow(j)

j <- j[order(j$Value, j$order_24),]
j$apha <- 1
j <- ddply(j, .(Value), transform, area24 = cumsum(apha*900))

j$area24[is.na(j$Value)] <- j$Value[is.na(j$Value)]


j$darea_24 <- j$n24 - j$area24

##file for nlcd24
m <- j[which(j$darea_24>=0),]

o <- j[which(j$darea_24<0),]


### land transition priority for nlcd class 23

order_23 <- 
  ifelse(o$trans_23>=23&o$trans_23<24&o$lndincl==1, 2+(24-o$trans_23), 
         ifelse(o$trans_23>=22&o$trans_23<23&o$lndincl==1, 3+(23-o$trans_23), 
                ifelse(o$trans_23>=21&o$trans_23<22&o$lndincl==1, 4+(22-o$trans_23), 
                       ifelse(o$trans_23>=31&o$trans_23<32&o$lndincl==1, 5+(32-o$trans_23), 
                              ifelse(h$trans_23>=52&h$trans_23<53&h$lndincl==1, 6+(53-h$trans_23),
                                     ifelse(h$trans_23>=71&h$trans_23<72&h$lndincl==1, 7+(72-h$trans_23),
                                            ifelse(o$trans_23>=81&o$trans_23<82&o$lndincl==1, 8+(82-o$trans_23), 
                                                   ifelse(o$trans_23>=82&o$trans_23<83&o$lndincl==1, 9+(83-o$trans_23), 
                                                          ifelse(o$trans_23>=42&o$trans_23<43&o$lndincl==1, 10+(43-o$trans_23), 
                                                                 ifelse(o$trans_23>=43&o$trans_23<44&o$lndincl==1, 11+(44-o$trans_23), 
                                                                        ifelse(o$trans_23>=41&o$trans_23<42&o$lndincl==1, 12+(42-o$trans_23), 
                                                                               20)))))))))))


p <- cbind(o, order_23)




p <- p[order(p$Value, p$order_23),]
p$apha <- 1
p <- ddply(p, .(Value), transform, area23 = cumsum(apha*900))
p$area23[is.na(p$Value)] <- p$Value[is.na(p$Value)]

p$darea_23 <- p$n23 - p$area23


r <- p[which(p$darea_23>=0),]

s <- p[which(p$darea_23 <0),]



### land transition priority for nlcd class 22

order_22 <- 
  ifelse(s$trans_22>=22&s$trans_22<23&s$lndincl==1, 3+(23-s$trans_22), 
         ifelse(s$trans_22>=21&s$trans_22<22&s$lndincl==1, 4+(22-s$trans_22), 
                ifelse(s$trans_22>=31&s$trans_22<32&s$lndincl==1, 5+(32-s$trans_22), 
                       ifelse(h$trans_22>=52&h$trans_22<53&h$lndincl==1, 6+(53-h$trans_22),
                              ifelse(h$trans_22>=71&h$trans_22<72&h$lndincl==1, 7+(72-h$trans_22),
                                     ifelse(s$trans_22>=81&s$trans_22<82&s$lndincl==1, 8+(82-s$trans_22), 
                                            ifelse(s$trans_22>=82&s$trans_22<83&s$lndincl==1, 9+(83-s$trans_22), 
                                                   ifelse(s$trans_22>=42&s$trans_22<43&s$lndincl==1, 10+(43-s$trans_22), 
                                                          ifelse(s$trans_22>=43&s$trans_22<44&s$lndincl==1, 11+(44-s$trans_22), 
                                                                 ifelse(s$trans_22>=41&s$trans_22<42&s$lndincl==1, 12+(42-s$trans_22), 
                                                                        20))))))))))


s <- cbind(s, order_22)

s <- s[order(s$Value, s$order_22),]
s$apha <- 1
s <- ddply(s, .(Value), transform, area22 = cumsum(apha*900))
s$area22[is.na(s$Value)] <- s$Value[is.na(s$Value)]

s$darea_22 <- s$n22 - s$area22


k <- s[which(s$darea_22>=0),]

l <- s[which(s$darea_22 <0),]




### land transition priority for nlcd class 21

order_21 <- 
  ifelse(l$trans_21>=21&l$trans_21<22&l$lndincl==1, 4+(22-l$trans_21), 
         ifelse(l$trans_21>=31&l$trans_21<32&l$lndincl==1, 5+(32-l$trans_21), 
                ifelse(h$trans_21>=52&h$trans_21<53&h$lndincl==1, 6+(53-h$trans_21),
                       ifelse(h$trans_21>=71&h$trans_21<72&h$lndincl==1, 7+(72-h$trans_21),
                              ifelse(l$trans_21>=81&l$trans_21<82&l$lndincl==1, 8+(82-l$trans_21), 
                                     ifelse(l$trans_21>=82&l$trans_21<83&l$lndincl==1, 9+(83-l$trans_21), 
                                            ifelse(l$trans_21>=42&l$trans_21<43&l$lndincl==1, 10+(43-l$trans_21), 
                                                   ifelse(l$trans_21>=43&l$trans_21<44&l$lndincl==1, 11+(44-l$trans_21), 
                                                          ifelse(l$trans_21>=41&l$trans_21<42&l$lndincl==1, 12+(42-l$trans_21), 
                                                                 20)))))))))

l <- cbind(l, order_21)

l <- l[order(l$Value, l$order_21),]
l$apha <- 1
l <- ddply(l, .(Value), transform, area21 = cumsum(apha*900))
l$area21[is.na(l$Value)] <- l$Value[is.na(l$Value)]

##l$darea_21 <- l$n21 - l$area21 
## results in ": non-numeric argument to binary operator"

l$darea_21 <- as.numeric(l$n21) - as.numeric(l$area21)

q <- l[which(l$darea_21 >=0),]

t <- l[which(l$darea_21 <0),]


t$LC <- floor(t$trans_21)



m$LC <- 24
r$LC <- 23
k$LC <- 22
q$LC <- 21

hNA <- h[is.na(h$nlcd),]

dat24 <- as.data.frame(cbind(m$longitude, m$latitude, m$LC))
colnames(dat24) <- c("longitude", "latitude","LC")
dat23 <- as.data.frame(cbind(r$longitude, r$latitude, r$LC))
colnames(dat23) <- c("longitude", "latitude","LC")
dat22 <- as.data.frame(cbind(k$longitude, k$latitude, k$LC))
colnames(dat22) <- c("longitude", "latitude","LC")
dat21 <- as.data.frame(cbind(q$longitude, q$latitude, q$LC))
colnames(dat21) <- c("longitude", "latitude","LC")
dato <- as.data.frame(cbind(t$longitude, t$latitude, t$LC))
colnames(dato) <- c("longitude", "latitude","LC")
datleft <- as.data.frame(cbind(hNA$longitude, hNA$latitude, hNA$nlcd_class))
colnames(datleft) <- c("longitude", "latitude","LC")

xfinal <- rbind(dat24, dat23, dat22, dat21, dato, datleft)


write.csv(xfinal, paste0(path1, out_table))

## read raster
lc_1a <- rasterFromXYZ(xfinal, crs="+proj=aea +lat_0=23 +lon_0=-96 +lat_1=29.5 +lat_2=45.5 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")

#writeRaster(lc_1a, paste0(path2, out_raster), format="GTiff", datatype="INT2S", overwrite=TRUE)

##
lc_1b <- projectRaster(lc_1a, nlcd_2000, method="ngb")
extent(lc_1b) <- extent(nlcd_2000)


new <- stack(lc_1b, nlcd_2000, slope, lndincl)
new <- as.data.frame(new, xy=TRUE)
colnames(new) <- c("longitude", "latitude","LC", "NLCD", "slope", "lndincl")

new$FLC <- 0

new$FLC <-   ifelse((new$LC==21|new$LC==22|new$LC==23|new$LC==24)&(new$NLCD==11),11,
                    ifelse((new$LC==21|new$LC==22|new$LC==23|new$LC==24)&(new$NLCD==90),90,
                           ifelse((new$LC==21|new$LC==22|new$LC==23|new$LC==24)&(new$NLCD==95),95,
                                  ifelse(new$LC==21&(new$NLCD>21&new$NLCD<=24),new$NLCD,
                                         ifelse(new$LC==22&(new$NLCD>22&new$NLCD<=24),new$NLCD,  
                                                ifelse(new$LC==23&(new$NLCD>23&new$NLCD<=24),new$NLCD,
                                                       ifelse(new$slope>30,new$NLCD, 
                                                              ifelse(new$lndincl==0,new$NLCD, new$LC))))))))



new <- new[c(-3,-4,-5,-6)]       

lc_1 <- rasterFromXYZ(new, crs="+proj=aea +lat_0=23 +lon_0=-96 +lat_1=29.5 +lat_2=45.5 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")
##


writeRaster(lc_1, paste0(path2, out_raster_adj), format="GTiff", datatype="INT2S", overwrite=TRUE)
##

}



