
library(reshape)
library(doBy)
library(plyr)
library(foreign)
library(dplyr)
library(rlist)
library(plyr)



## area dataset preparation
urban_area <- read.csv(file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_urban_area_all_scenarios.csv", header=TRUE)

## nlcd fractions
nlcd_orig_ssp1 <- read.csv(file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Orig_SSP1.csv", header=TRUE)
nlcd_orig_ssp2 <- read.csv(file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Orig_SSP2.csv", header=TRUE)
nlcd_orig_ssp3 <- read.csv(file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Orig_SSP3.csv", header=TRUE)
nlcd_orig_ssp4 <- read.csv(file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Orig_SSP4.csv", header=TRUE)
nlcd_orig_ssp5 <- read.csv(file="HYBRD_Model_code/urban_land_allocation/outputs/predicted_nlcd_fraction_Orig_SSP5.csv", header=TRUE)


## predictors
nlcd_predictors <-read.csv(file="HYBRD_Model_code/urban_land_allocation/inputs/nlcd_scenarios_allyears.csv", header=TRUE)

urban_area_predictors <-read.csv(file="HYBRD_Model_code/urban_land_allocation/inputs/gao_nlcd_1km_totalarea_all_scenarios.csv", header=TRUE)


## nlcd_fraction prep

nlcd_orig_ssp1 <- cbind(nlcd_predictors, nlcd_orig_ssp1)
nlcd_orig_ssp2 <- cbind(nlcd_predictors, nlcd_orig_ssp2)
nlcd_orig_ssp3 <- cbind(nlcd_predictors, nlcd_orig_ssp3)
nlcd_orig_ssp4 <- cbind(nlcd_predictors, nlcd_orig_ssp4)
nlcd_orig_ssp5 <- cbind(nlcd_predictors, nlcd_orig_ssp5)



# remove columns 1, 2, 6

nlcd_orig_ssp1 <- nlcd_orig_ssp1[c(-1,-2,-6,-7,-8,-9,-10,-11,-12,-13,-14)]
nlcd_orig_ssp2 <- nlcd_orig_ssp2[c(-1,-2,-6,-7,-8,-9,-10,-11,-12,-13,-14)]
nlcd_orig_ssp3 <- nlcd_orig_ssp3[c(-1,-2,-6,-7,-8,-9,-10,-11,-12,-13,-14)]
nlcd_orig_ssp4 <- nlcd_orig_ssp4[c(-1,-2,-6,-7,-8,-9,-10,-11,-12,-13,-14)]
nlcd_orig_ssp5 <- nlcd_orig_ssp5[c(-1,-2,-6,-7,-8,-9,-10,-11,-12,-13,-14)]


colnames(nlcd_orig_ssp1) <- c("Value", "urb_type", "Year", "ncld_frac")
colnames(nlcd_orig_ssp2) <- c("Value", "urb_type", "Year", "ncld_frac")
colnames(nlcd_orig_ssp3) <- c("Value", "urb_type", "Year", "ncld_frac")
colnames(nlcd_orig_ssp4) <- c("Value", "urb_type", "Year", "ncld_frac")
colnames(nlcd_orig_ssp5) <- c("Value", "urb_type", "Year", "ncld_frac")


#orig_ssp1
nlcd_orig_ssp1$urb_type <- as.factor(nlcd_orig_ssp1$urb_type)
nlcd_orig_ssp1_reshape <- cast(nlcd_orig_ssp1, Value + Year ~ urb_type, mean)
nlcd_orig_ssp1_reshape$Value_yr <- paste0(nlcd_orig_ssp1_reshape$Value,"_",nlcd_orig_ssp1_reshape$Year)
nlcd_orig_ssp1_reshape$SSP <- "ssp1"


#orig_ssp2
nlcd_orig_ssp2$urb_type <- as.factor(nlcd_orig_ssp2$urb_type)
nlcd_orig_ssp2_reshape <- cast(nlcd_orig_ssp2, Value + Year ~ urb_type, mean)
nlcd_orig_ssp2_reshape$Value_yr <- paste0(nlcd_orig_ssp2_reshape$Value,"_",nlcd_orig_ssp2_reshape$Year)
nlcd_orig_ssp2_reshape$SSP <- "ssp2"

#orig_ssp3
nlcd_orig_ssp3$urb_type <- as.factor(nlcd_orig_ssp3$urb_type)
nlcd_orig_ssp3_reshape <- cast(nlcd_orig_ssp3, Value + Year ~ urb_type, mean)
nlcd_orig_ssp3_reshape$Value_yr <- paste0(nlcd_orig_ssp3_reshape$Value,"_",nlcd_orig_ssp3_reshape$Year)
nlcd_orig_ssp3_reshape$SSP <- "ssp3"

#orig_ssp4
nlcd_orig_ssp4$urb_type <- as.factor(nlcd_orig_ssp4$urb_type)
nlcd_orig_ssp4_reshape <- cast(nlcd_orig_ssp4, Value + Year ~ urb_type, mean)
nlcd_orig_ssp4_reshape$Value_yr <- paste0(nlcd_orig_ssp4_reshape$Value,"_",nlcd_orig_ssp4_reshape$Year)
nlcd_orig_ssp4_reshape$SSP <- "ssp4"

#orig_ssp5
nlcd_orig_ssp5$urb_type <- as.factor(nlcd_orig_ssp5$urb_type)
nlcd_orig_ssp5_reshape <- cast(nlcd_orig_ssp5, Value + Year ~ urb_type, mean)
nlcd_orig_ssp5_reshape$Value_yr <- paste0(nlcd_orig_ssp5_reshape$Value,"_",nlcd_orig_ssp5_reshape$Year)
nlcd_orig_ssp5_reshape$SSP <- "ssp5"


nlcd_orig_fraction <- rbind(nlcd_orig_ssp1_reshape, nlcd_orig_ssp2_reshape, nlcd_orig_ssp3_reshape, nlcd_orig_ssp4_reshape, nlcd_orig_ssp5_reshape)

nlcd_orig_fraction$SSP <- ifelse(nlcd_orig_fraction$Year==2000, "base", nlcd_orig_fraction$SSP)
  
nlcd_orig_fraction$Value_yr_SSP <- paste0(nlcd_orig_fraction$Value_yr,"_",nlcd_orig_fraction$SSP)



##prep preditor data urban area

colnames(urban_area) <-c("x","urban_area")
colnames(urban_area_up) <-c("x","urban_area")


predictors <- urban_area_predictors


colnames(predictors)[1] <- "Value"
colnames(predictors_up)[1] <- "Value"
predictors$Value <- as.factor(predictors$Value)
predictors_up$Value <- as.factor(predictors_up$Value)

urban_area2 <- cbind(predictors, urban_area)


urban_area2 <- urban_area2[c(-2,-5:-20,-22)]


colnames(urban_area2) <- c("Value","Year","SSP","urb_type","urban_area")

area_pred <- cast(urban_area2, Value + Year+ SSP ~ urb_type, mean)
colnames(area_pred) <- c("Value", "SSP", "Year", "u21_24", "u22_24")


area_pred$urban_area <- pmax(area_pred$u21_24, area_pred$u22_24)
area_pred$Value_yr <- paste0(area_pred$Value, "_", area_pred$Year)
area_pred$Value_yr_SSP <- paste0(area_pred$Value_yr,"_",area_pred$SSP)


area_pred <- merge(area_pred,nlcd_orig_fraction, by="Value_yr_SSP", all.x=TRUE)
area_pred <- area_pred[c(-8,-9,-10,-15,-16)]

colnames(area_pred) <- c("Value_yr_SSP", "Value", "SSP","Year","u21_24", "u22_24","urban_area","f21","f22","f23", "f24")        


## weighted average intensification approach

area_pred$uf_sum <- rowSums(area_pred[c("f21", "f22","f23","f24")])
area_pred$f21a <- area_pred$f21/area_pred$uf_sum
area_pred$f22a <- area_pred$f22/area_pred$uf_sum
area_pred$f23a <- area_pred$f23/area_pred$uf_sum
area_pred$f24a <- area_pred$f24/area_pred$uf_sum

area_pred$n21 <- area_pred$urban_area*area_pred$f21a
area_pred$n22 <- area_pred$urban_area*area_pred$f22a
area_pred$n23 <- area_pred$urban_area*area_pred$f23a
area_pred$n24 <- area_pred$urban_area*area_pred$f24a


write.csv(area_pred, file="HYBRD_Model_code/spatial_model/scenario_files/urban_area_nlcd_fraction_allscenarios_original.csv")



#######
## alternative intensification approach

area_pred2 <- area_pred

area_pred2$f24a <- area_pred2$f24
area_pred2$f23a <- (1-area_pred2$f24a)*(area_pred2$f23/(area_pred2$uf_sum-area_pred2$f24))
area_pred2$f22a <- (1- (area_pred2$f23a + area_pred2$f24a))*(area_pred2$f22/(area_pred2$uf_sum-(area_pred2$f23 + area_pred2$f24)))
area_pred2$f21a <- (1-(area_pred2$f22a + area_pred2$f23a + area_pred2$f24a))*(area_pred2$f21/(area_pred2$uf_sum-(area_pred2$f22+area_pred2$f23 + area_pred2$f24)))

area_pred2$n21 <- area_pred2$urban_area*area_pred2$f21a
area_pred2$n22 <- area_pred2$urban_area*area_pred2$f22a
area_pred2$n23 <- area_pred2$urban_area*area_pred2$f23a
area_pred2$n24 <- area_pred2$urban_area*area_pred2$f24a

area_pred2$testum <- area_pred2$f24a + area_pred2$f23a + area_pred2$f22a + area_pred2$f21a
area_pred2 <- area_pred2 [c(-21)]


write.csv(area_pred2, file="HYBRD_Model_code/spatial_model/scenario_files/urban_area_nlcd_fraction_allscenarios_original_intensity.csv")




###  Final scenario file step


#scenario 1
area_ssp1_2010 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2010),]
area_ssp1_2020 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2020),]
area_ssp1_2030 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2030),]
area_ssp1_2040 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2040),]
area_ssp1_2050 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2050),]
area_ssp1_2060 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2060),]
area_ssp1_2070 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2070),]
area_ssp1_2080 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2080),]
area_ssp1_2090 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2090),]
area_ssp1_2100 <- area_pred[which(area_pred$SSP=="ssp1"&area_pred$Year==2100),]



#scenario 2
area_ssp2_2010 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2010),]
area_ssp2_2020 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2020),]
area_ssp2_2030 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2030),]
area_ssp2_2040 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2040),]
area_ssp2_2050 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2050),]
area_ssp2_2060 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2060),]
area_ssp2_2070 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2070),]
area_ssp2_2080 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2080),]
area_ssp2_2090 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2090),]
area_ssp2_2100 <- area_pred[which(area_pred$SSP=="ssp2"&area_pred$Year==2100),]

#scenario 3
area_ssp3_2010 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2010),]
area_ssp3_2020 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2020),]
area_ssp3_2030 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2030),]
area_ssp3_2040 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2040),]
area_ssp3_2050 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2050),]
area_ssp3_2060 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2060),]
area_ssp3_2070 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2070),]
area_ssp3_2080 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2080),]
area_ssp3_2090 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2090),]
area_ssp3_2100 <- area_pred[which(area_pred$SSP=="ssp3"&area_pred$Year==2100),]


#scenario 4
area_ssp4_2010 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2020),]
area_ssp4_2020 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2020),]
area_ssp4_2030 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2030),]
area_ssp4_2040 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2040),]
area_ssp4_2050 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2050),]
area_ssp4_2060 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2060),]
area_ssp4_2070 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2070),]
area_ssp4_2080 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2080),]
area_ssp4_2090 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2090),]
area_ssp4_2100 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2100),]

#scenario 5
area_ssp5_2010 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2010),]
area_ssp5_2020 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2020),]
area_ssp5_2030 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2030),]
area_ssp5_2040 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2040),]
area_ssp5_2050 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2050),]
area_ssp5_2060 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2060),]
area_ssp5_2070 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2070),]
area_ssp5_2080 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2080),]
area_ssp5_2090 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2090),]
area_ssp5_2100 <- area_pred[which(area_pred$SSP=="ssp5"&area_pred$Year==2100),]

