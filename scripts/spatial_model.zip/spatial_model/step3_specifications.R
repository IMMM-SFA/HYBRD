
## scenario table for structuring loop
## select one of the scenarios

sdl <- read.csv(file="HYBRD_Model_code/spatial_model/scenario_files/ssp1_scenario_table.csv")


##  select land inclusion layer
## one of the zoning scenarios
lndincl <- vhi_LA


### urban land intensity

# weighted average method
#use area_pred

### intensification method
#use area_pred2


### slope threshold
#Slope <=30%
#see LA's baseline hillside ordinance

## output pathways

## raster tables
path1 <- "HYBRD_Model_code/spatial_model/outputs/Tables/"

## rasters unadjusted and adjusted
path2 <- "HYBRD_Model_code/spatial_model/outputs/Rasters/"


