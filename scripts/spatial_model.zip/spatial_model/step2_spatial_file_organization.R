
library(raster)
library(sf)
library(rgdal)
library(sp)
library(bnspatial)
library(RGBL)

#grid corresponding to SELECT

grid <- raster("HYBRD_inputs/spatial_model_inputs/1_km_grid/1km_grid.tif", datatype="INT2S")

#nlcd base
nlcd_2000 <- raster("HYBRD_inputs/spatial_model_inputs/nlcd_lc/NLCD_2001_Land_Cover_L48_20190424.tif", layer=1, datatype="INT2S", values=TRUE)
nlcd_2000 <- setValues(raster(nlcd_2000), nlcd_2000[])



#lc_2000 <- extractByMask(nlcd_2000, grid, spatial=TRUE)
writeRaster(nlcd_2000, file="HYBRD_Model_code/spatial_model/outputs/base2000.tif", format="GTiff", datatype="INT2S", overwrite=TRUE)


plot(nlcd_2000)


#land inclusion
low_LA <- raster("HYBRD_inputs/spatial_model_inputs/zoning/LI_LA.tif", datatype="INT2S")
med_LA <- raster("HYBRD_inputs/spatial_model_inputs/zoning/MI_LA.tif", datatype="INT2S")
hi_LA <- raster("HYBRD_inputs/spatial_model_inputs/zoning/HI_LA.tif", datatype="INT2S")
vhi_LA <- raster("HYBRD_inputs/spatial_model_inputs/zoning/VHI_LA.tif", datatype="INT2S")


#crs for USA Contiguous Albers Equal Area Conic - 5070 or 102003
#+proj=aea +lat_1=29.5 +lat_2=45.5 +lat_0=37.5 +lon_0=-96 +x_0=0 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs

extent(low_LA) <- extent(nlcd_2000)
extent(med_LA) <- extent(nlcd_2000)
extent(hi_LA) <- extent(nlcd_2000)
extent(vhi_LA) <- extent(nlcd_2000)

#set both nlcd and lndincl to extent of grid

## Slope
slope <- raster("HYBRD_inputs/spatial_model_inputs/slope/slope_percent_trans.tif", datatype="FLT4S")
slope <- projectRaster(slope, nlcd_2000, method="bilinear")
extent(slope) <- extent(nlcd_2000)

#aggregrations, resampling, and projections
grid2 <- projectRaster(grid, nlcd_2000, method="ngb")

#low_LA <- resample(low_LA, nlcd_2000, method="ngb")
#med_LA <- resample(med_LA, nlcd_2000, method="ngb")
#hi_LA <- resample(hi_LA, nlcd_2000, method="ngb")
#vhi_LA <- resample(vhi_LA, nlcd_2000, method="ngb")






